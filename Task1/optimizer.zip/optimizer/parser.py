

DATES_TO_FIND = [
    '01-Jan-2016',
    '31-Jan-2017',
    '31-Jan-2018',
    '31-Jan-2019',
    '31-Jan-2020',
    '30-Jan-2021',
    '30-Jan-2022',
    '30-Jan-2023',
    '30-Jan-2024',
]

def get_prod_from_line(line):
    find = 'PROD:ORAT:'
    line = line.split(find)[-1]
    line = line.replace(' ', '')
    res = line.split(':')[0]
    return(res)

def filter_values(data):
    new_data = {}
    for key, value in data.items():
        if key in DATES_TO_FIND:
            new_data[key] = value * 1000
    return new_data

def parse_file(filename):
    data = {}
    watch_for_prod = False
    prod = 0
    with open(filename, 'r') as file:
        for i, line in enumerate(file, 1):
            if line.startswith('Report step '):
                date = line.split('= ')[-1][:-1]
                data[date] = float(prod)
            if 'CUMULATIVE PRODUCTION/INJECTION REPORT' in line:
                watch_for_prod = True
            if watch_for_prod and line.startswith(':    PROD:'):
                if 'PROD:ORAT:' not in line:
                    raise ValueError('wrong line')
                prod = get_prod_from_line(line)
                # data[date] = float(prod)
                watch_for_prod = False

    print(filter_values(data))
    return list(filter_values(data).values())