from parser import *
import matplotlib.pyplot as plt
import numpy as np

DATES_TO_FIND = [
    '01-Jan-2016',
    '31-Jan-2017',
    '31-Jan-2018',
    '31-Jan-2019',
    '31-Jan-2020',
    '30-Jan-2021',
    '30-Jan-2022',
    '30-Jan-2023',
    '30-Jan-2024',
]
REQUIRED_DATA = [7300000, 15220000, 22465200, 28266890, 32960926, 36983876, 40550352, 43696008, 46461860]
PATH_TO_FILE = '../SPE1CASE1.PRT'

res = parse_file(PATH_TO_FILE)
plt.subplot(2, 1, 1)
plt.plot(DATES_TO_FIND, res, label='res')
plt.plot(DATES_TO_FIND, REQUIRED_DATA, label='target')
plt.legend()
plt.subplot(2, 1 , 2)
y = (np.abs(np.array(res) - np.array(REQUIRED_DATA)) / np.array(REQUIRED_DATA))
plt.plot(DATES_TO_FIND, y, label='diff')
plt.legend()
plt.show()

print(res[0])